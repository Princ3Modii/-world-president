# WORLD PRESIDENT

Jeu de simulation présidentielle jouable dans un navigateur.

## Lancer
Ouvrir `index.html` dans un navigateur moderne.

## Mettre en ligne gratuitement
GitHub Pages peut héberger directement les fichiers HTML/CSS/JavaScript d'un dépôt. Le fichier d'entrée doit être `index.html`.
1. Créer un dépôt GitHub.
2. Envoyer `index.html`.
3. Settings → Pages → Deploy from a branch → `main` → `/root`.
4. Ouvrir l'adresse fournie par GitHub Pages.

Documentation officielle : https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
